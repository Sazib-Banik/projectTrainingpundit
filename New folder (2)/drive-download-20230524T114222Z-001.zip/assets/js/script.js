// banner carousel active
$(".bxslider").bxSlider({
  infiniteLoop: false,
  hideControlOnEnd: true,
});
// counter js active
$(".counter").counterUp({
  delay: 10,
  time: 2500,
});
//set your goal carousel active
// $(".your-goal-carousel").owlCarousel({
//   margin: 7,
//   dots: false,
//   nav: true,
//   autoplay: false,
//   autoplayTimeout: 1000,
//   autoplayHoverPause: true,
//   responsive: {
//     0: {
//       items: 1,
//     },
//     600: {
//       items: 3,
//     },
//     1000: {
//       items: 4,
//     },
//   },
// });
// $(".top-course-carousel").owlCarousel({
//   margin: 7,
//   dots: false,
//   nav: true,
//   autoplay: false,
//   autoplayTimeout: 1000,
//   autoplayHoverPause: true,
//   responsive: {
//     0: {
//       items: 1,
//     },
//     600: {
//       items: 3,
//     },
//     1000: {
//       items: 4,
//     },
//   },
// });
// venobox active
new VenoBox({
  selector: ".venobox",
});
// top-category carousel
// $(".top-category-carousel").owlCarousel({
//   loop: true,
//   margin: 7,
//   dots: false,
//   nav: true,
//   autoplay: false,
//   autoplayTimeout: 1000,
//   autoplayHoverPause: true,
//   responsive: {
//     0: {
//       items: 1,
//     },
//     600: {
//       items: 3,
//     },
//     1000: {
//       items: 4,
//     },
//   },
// });
//success story carousel
// var swiper = new Swiper(".success-story", {
//   effect: "coverflow",
//   centeredSlides: true,
//   autoplay: {
//     delay: 3500,
//     disableOnInteraction: false,
//   },
//   grabCursor: true,
//   centeredSlides: true,
//   slidesPerView: "auto",
//   coverflowEffect: {
//     rotate: 50,
//     stretch: 0,
//     depth: 100,
//     modifier: 1,
//     slideShadows: true,
//   },
// });
//feature-course carousel
// $(".feature-carousel").owlCarousel({
//   loop: true,
//   margin: 7,
//   dots: false,
//   nav: true,
//   autoplay: false,
//   autoplayTimeout: 1000,
//   autoplayHoverPause: true,
//   responsive: {
//     0: {
//       items: 1,
//     },
//     600: {
//       items: 3,
//     },
//     1000: {
//       items: 4,
//     },
//   },
// });
//partners-part carousel
// $('.partnerslider').bxSlider({
//   minSlides: 4,
//   maxSlides: 4,
//   slideWidth: 170,
//   slideMargin: 10,
//   ticker: true,
//   speed: 10000
// });
